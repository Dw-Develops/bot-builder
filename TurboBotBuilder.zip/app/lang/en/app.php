<?php

return array(

    /*
    |--------------------------------------------------------------------------
    | Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'actions' => "Actions",
    'add_bot' => "Add Bot",
    'add_message' => "Add Message",
    'add_menu' => "Add Menu Link",
    'admin_profile' => "Admin's Profile",
    'bot' => "Your Bot",
    'continue' => "Continue",
    'create_bot' => "Create a Bot",
    'create_message' => "Create a Message",
    'create_menu_item' => "Create a Menu Static Link",
    'import_messages' => "Import Messages",
    'export_messages' => "Export Messages",
    'import_messages_csv' => "Import Messages from CSV file",
    'edit_bot' => "Edit Bot",
    'edit_menu' => "Edit Menu",
    'edit_messages' => "Edit Messages",
    'forgot_password' => "Forgot password",
    'info_bot' => "Add following to your Facebook application",
    'instructions' => "Instructions",
    'no_bots' => "No Bots Yet",
    'no_messages' => "No Messages Yet",
    'no_menu' => "No Menu Items Yet",
    'reg_title' => "Account Wizard",
    'show_config' => "Configuration",
    'sign_in_title' => "Please Sign In",
    'title' => "Turbo Bot Builder",

);
