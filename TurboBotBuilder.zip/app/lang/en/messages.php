<?php

return array(

    'bot_created' => "Successfully created the bot!",
    'bot_deleted' => "Successfully deleted the bot!",
    'bot_updated' => "Successfully updated the bot!",
    'following_errors' => "The following errors occurred",
    'login_error' => "Your username/password combination was incorrect",
    'logout' => "Your are now logged out.",
    'message_created' => "Successfully created the message",
    'message_deleted' => "Successfully deleted the message",
    'message_updated' => "Successfully updated the message",
    'menu_created' => "Successfully created the menu link",
    'menu_deleted' => "Successfully deleted the menu link",
    'menu_updated' => "Successfully updated the menu link",
    'pass_sent' => "The new password has been sent.",
    'profile_updated' => "Your Profile is Updated!",
    'registration_tanks' => "Thanks for registering!",
    'wrong_email' => "We cannot find the email you provided",
    'you_logged_in' => "You are now logged in!",



    'password' => "Passwords must be at least six characters and match the confirmation.",
    'user' => "We can't find a user with that e-mail address.",
    'token' => "This password reset token is invalid.",
    'sent' => "Password reminder sent!",

);
