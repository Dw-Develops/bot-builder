<?php

return array(

    /*
    |--------------------------------------------------------------------------
    | Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'content' => "Content",
    'bot_says' => "Bot says",
    'user_says' => "User says",
    'create' => "Create",
    'email' => "Email",
    'link_title' => "Link Title",
    'link_url' => "Link Url",
    'greeting' => "Greeting Text",
    'ununderstood' => "Default message",
    'fill_form_text' => "Please fill the form",
    'name' => "Name",
    'page_access_token' => "Page access token (copy from Facebook)",
    'password' => "Password",
    'password_confirmation' => "Password Confirmation",
    'save' => "Save",
    'sign_in' => "Sign in",
    'submit' => "Submit",
    'upload_file' => "Upload file",
    'verify_token' => "Verify Token (randomly generated)",
    'webhook_url' => "Callback URL (webhook, paste to Facebook)",

);
