<h2>{{ $data->name }} Bot Management</h2>

<a href="">edit messages</a> <br />
<a href="">show configuration</a> <br />



