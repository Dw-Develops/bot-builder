@extends('layouts.app')

@section('htmlheader_title')
    {{--Integrations--}}
@endsection
@section('main-content')


<h1>{{ trans('app.edit_bot') }}</h1>

<!-- if there are creation errors, they will show here -->
{{ HTML::ul($errors->all()) }}

{{ Form::model($data, array('url' => array('bots/' . $currentBot->id . '/messages', $data->id), 'method' => 'PUT')) }}

<div class="form-group">
    {{ Form::label('user_says', trans('forms.user_says')) }}
    {{ Form::text('user_says', Input::old('user_says'), array('class' => 'form-control')) }}
</div>

<div class="form-group">
    {{ Form::label('bot_says', trans('forms.bot_says')) }}
    {{ Form::text('bot_says', Input::old('bot_says'), array('class' => 'form-control')) }}
</div>



{{ Form::submit(trans('forms.save'), array('class' => 'btn btn-primary')) }}

{{ Form::close() }}


@endsection
