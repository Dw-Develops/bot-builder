@extends('layouts.app')

@section('htmlheader_title')
    {{--Integrations--}}
@endsection
@section('main-content')

<script src="//cdn.ckeditor.com/4.5.11/standard/ckeditor.js"></script>
<h1>{{ trans('app.create_message') }}</h1>

<!-- if there are creation errors, they will show here -->
{{ HTML::ul($errors->all()) }}

{{ Form::open(array('url' => 'bots/' . $currentBot->id . '/messages')) }}

<div class="form-group">
    {{ Form::label('user_says', trans('forms.user_says')) }}
    {{ Form::text('user_says', Input::old('user_says'), array('class' => 'form-control')) }}
</div>

<div class="form-group">
    {{ Form::label('bot_says', trans('forms.bot_says')) }}
    {{ Form::text('bot_says', Input::old('bot_says'), array('class' => 'form-control')) }}
</div>


{{--
<div class="form-group">
    {{ Form::label('webhook_url', trans('forms.webhook_url')) }}
    {{ Form::text('webhook_url', url('fbot') . '/' . $data['id'], array('class' => 'form-control')) }}
</div>
--}}


{{ Form::submit(trans('forms.create'), array('class' => 'btn btn-primary')) }}

{{ Form::close() }}

{{--<script>
    CKEDITOR.replace('content');
</script>--}}

@endsection
