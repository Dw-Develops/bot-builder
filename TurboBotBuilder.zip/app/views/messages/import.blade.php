@extends('layouts.app')

@section('htmlheader_title')
    {{--Integrations--}}
@endsection

@section('main-content')

    <h2>{{ trans('app.import_messages_csv') }}</h2>
    {{ Form::open(array('url' => 'bots/' . $currentBot->id . '/messages/import', 'files' => true)) }}
        <div class="form-group">
            {{ Form::label('csv_file', trans('forms.upload_file')) }}
            {{ Form::file('csv_file') }}
        </div>
        {{ Form::submit(trans('forms.submit'), array('class' => 'btn btn-primary')) }}
    {{ Form::close() }}


@endsection
