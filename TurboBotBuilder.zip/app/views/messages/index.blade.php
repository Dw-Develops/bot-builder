@extends('layouts.app')

@section('htmlheader_title')
    {{--Integrations--}}
@endsection

@section('main-content')

    <div>
        <a class="btn btn-primary" href="{{ url('bots/' . $currentBot->id . '/messages/create') }}">{{ trans('app.add_message') }}</a>
    </div>
    <table class="table table-striped">
        <thead>
        <tr>
            <th>{{ trans('forms.user_says') }}</th>
            <th>{{ trans('forms.bot_says') }}</th>
            <th>{{ trans('app.actions') }}</th>
        </tr>
        </thead>
        <tbody>
            @forelse($data as $key => $value)
                <tr>
                    {{--<td>{{ $value->id }}</td>--}}
                    <td>{{ $value->user_says }}</td>
                    <td>{{ $value->bot_says }}</td>

                    <!-- we will also add show, edit, and delete buttons -->
                    <td>
                        {{--<a href="{{ url('bots/' . $value->id) }}" class="action-icon" title="view" target="_blank"><span class="glyphicon glyphicon-eye-open"></span></a>--}}

                        <a href="{{ url('bots/' . $currentBot->id . '/messages/' . $value->id . '/edit') }}" class="action-icon"><span class="glyphicon glyphicon-pencil"></span></a>

                        {{ Form::open(array(
                            'url' =>'bots/' . $currentBot->id . '/messages/' . $value->id,
                            'class' => 'pull-right', 'id' => 'form'. $value->id))
                        }}
                        {{ Form::hidden('_method', 'DELETE') }}
                        {{--{{ Form::submit('Delete this Post', array('class' => 'btn btn-warning', 'onClick' => 'return confirm("Are you sure you want to remove the post?")')) }}--}}
                        <a onclick="if (confirm('Are you sure?')) document.getElementById('form{{ $value->id }}').submit();"><span class="glyphicon glyphicon-trash"></span></a>
                        {{ Form::close() }}
                    </td>
                </tr>
            @empty
                <tr><td colspan="99">{{ trans('app.no_messages') }}</td></tr>
            @endforelse
        </tbody>
    </table>
@endsection
