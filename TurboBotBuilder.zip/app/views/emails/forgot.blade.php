<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<h2>Hi</h2>

<div>
    Your new password: {{ $data }}<br/>
    Please log in at <a href="{{ url('admin/login') }}">{{ url('admin/login') }}</a>
</div>
</body>
</html>
