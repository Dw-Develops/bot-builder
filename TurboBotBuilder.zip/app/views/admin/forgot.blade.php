@extends('layouts.admin')

@section('htmlheader_title')
    {{--Integrations--}}
@endsection

@section('navbar')
@endsection
@section('sidebar')
@endsection


@section('main-content')

    <div class="col-md-4 col-md-offset-4">
        <h3>{{ trans('app.forgot_password') }}</h3>
        {{ Form::open(array('url'=>'admin/forgot', 'class'=>'form-signin')) }}

            <input type="hidden" name="action" value="17">
            <div class="form-group">
                <label id="username">{{ trans('forms.email') }}</label>
                <input class="form-control" type="text" name="email" id="email" value="{{ Input::old('email') }}">
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-default save-btn" value="{{ trans('forms.submit') }}">
            </div>
            <div class="form-group">
                <a href="{{ url('admin/login') }}">Login</a>
            </div>
        {{ Form::close() }}
    </div>

@endsection
