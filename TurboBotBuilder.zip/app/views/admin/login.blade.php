@extends('layouts.admin')

@section('htmlheader_title')
    {{--Integrations--}}
@endsection

@section('navbar')
@endsection
@section('sidebar')
@endsection


@section('main-content')

    <div class="container">
        <div class="well">
            <div class="text-left">

                {{ Form::open(array('url'=>'admin/login', 'class'=>'form-signin')) }}
                    <input type="hidden" name="return_url" value="">
                    <div class="login-container">
                        <div class="row">
                            <div class="col-md-4 col-md-offset-4">
                                <div class="panel panel-default ">
                                    <div class="panel-heading">
                                        <h2 class="panel-title">{{ trans('app.sign_in_title') }}</h2>
                                    </div>
                                    <div class="panel-body">
                                        <div class="form-group">
                                            {{ Form::text('email', null, array('class'=>'form-control', 'placeholder'=>'Email Address')) }}
                                        </div>
                                        <div class="form-group">
                                            {{ Form::password('password', array('class'=>'form-control', 'placeholder'=>'Password')) }}
                                        </div>
                                        <div class="checkbox">
                                            <label class="checkbox">
                                                <input type="checkbox" name="remember" value="1"> remember me
                                            </label>
                                        </div>
                                        {{ Form::submit(trans('forms.sign_in'), array('class'=>'btn btn-large btn-primary btn-block'))}}


                                        <label>
                                            <a href="{{ url('admin/forgot') }}">{{ trans('app.forgot_password') }}?</a>
                                        </label>
                                        {{ Form::close() }}

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>




                <script>
                    document.forms[0].email.focus();
                </script>

                <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
                <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

            </div></div></div>

@endsection
