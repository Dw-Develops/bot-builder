@extends('layouts.app')

@section('htmlheader_title')
    {{--Integrations--}}
@endsection
@section('main-content')
    <h1>{{ trans('app.admin_profile') }}</h1>
    <hr />
    <div class="col-md-5">
        <!-- if there are creation errors, they will show here -->
        {{ HTML::ul($errors->all()) }}

        {{ Form::open(array('url'=>'admin/profile', 'class'=>'')) }}
            <div class="form-group">
                {{ Form::label('email', trans('forms.email')) }}
                {{ Form::text('email', null, array('class'=>'form-control', 'placeholder'=>'Email Address')) }}
            </div>
            <div class="form-group">
                {{ Form::label('password', trans('forms.password')) }}
                {{ Form::password('password', array('class'=>'form-control', 'placeholder'=>'Password')) }}
            </div>
            {{ Form::submit('Update', array('class'=>'btn btn-large btn-primary btn-block'))}}
        {{ Form::close() }}
    </div>
@endsection
