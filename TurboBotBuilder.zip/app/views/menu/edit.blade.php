@extends('layouts.app')

@section('htmlheader_title')
    {{--Integrations--}}
@endsection
@section('main-content')


<h1>{{ trans('app.edit_bot') }}</h1>

<!-- if there are creation errors, they will show here -->
{{ HTML::ul($errors->all()) }}

{{ Form::model($data, array('url' => array( 'bots/' . $currentBot->id . '/menu', $data->id), 'method' => 'PUT')) }}

<div class="form-group">
    {{ Form::label('title', trans('forms.link_title')) }}
    {{ Form::text('title', Input::old('title'), array('class' => 'form-control')) }}
</div>

<div class="form-group">
    {{ Form::label('url', trans('forms.link_url')) }}
    {{ Form::text('url', Input::old('url'), array('class' => 'form-control')) }}
</div>


{{ Form::submit(trans('forms.save'), array('class' => 'btn btn-primary')) }}

{{ Form::close() }}


@endsection
