@extends('layouts.app')

@section('htmlheader_title')
    {{--Integrations--}}
@endsection
@section('main-content')

<script src="//cdn.ckeditor.com/4.5.11/standard/ckeditor.js"></script>
<h1>{{ trans('app.create_menu_item') }}</h1>

<!-- if there are creation errors, they will show here -->
{{ HTML::ul($errors->all()) }}

{{ Form::open(array('url' => 'bots/' . $currentBot->id . '/menu')) }}

<div class="form-group">
    {{ Form::label('title', trans('forms.link_title')) }}
    {{ Form::text('title', Input::old('title'), array('class' => 'form-control')) }}
</div>

<div class="form-group">
    {{ Form::label('url', trans('forms.link_url')) }}
    {{ Form::text('url', Input::old('url'), array('class' => 'form-control')) }}
</div>


{{--
<div class="form-group">
    {{ Form::label('webhook_url', trans('forms.webhook_url')) }}
    {{ Form::text('webhook_url', url('fbot') . '/' . $data['id'], array('class' => 'form-control')) }}
</div>
--}}


{{ Form::submit(trans('forms.create'), array('class' => 'btn btn-primary')) }}

{{ Form::close() }}

{{--<script>
    CKEDITOR.replace('content');
</script>--}}

@endsection
