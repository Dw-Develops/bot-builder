@extends('layouts.app')

@section('htmlheader_title')
    {{--Integrations--}}
@endsection
@section('main-content')


<h1>{{ trans('app.info_bot') }}</h1>

<!-- if there are creation errors, they will show here -->
{{ HTML::ul($errors->all()) }}

{{ Form::model($data, array('route' => array('bots.update', $data->id), 'method' => 'PUT')) }}


<div class="form-group">
    {{ Form::label('verify_token', trans('forms.verify_token')) }}
    {{ Form::text('verify_token', Input::old('verify_token') ? Input::old('verify_token') : $data['token'], array('class' => 'form-control', 'readonly')) }}
</div>

<div class="form-group">
    {{ Form::label('webhook_url', trans('forms.webhook_url')) }}
    {{ Form::text('webhook_url', Input::old('webhook_url'), array('class' => 'form-control', 'readonly')) }}
</div>

{{ Form::close() }}

<a href="{{ url('bots/' . $data->id . '/messages') }}" class="btn btn-primary">{{ trans('app.continue') }}</a>

@endsection
