<!-- Main Footer -->
<footer class="main-footer" style="background-color: #f5f5f5;">
    <div class="container text-center">
        <div class="hidden-xs">
            <strong>Copyright &copy; {{ trans('app.title') }} v1.0.0 </strong>
        </div>
    </div>
</footer>

<!-- Latest compiled and minified JavaScript -->
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>

<!-- DataTables JavaScript -->
<script src="{{ asset('assets/js/vendor/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('assets/js/vendor/dataTables.bootstrap.min.js') }}"></script>

<!-- TinyMCE editor -->
{{--<script src="{{ asset('assets/js/vendor/tinymce/tinymce.min.js') }}"></script>--}}

<!-- Custom Admin scripts -->
<script src="{{ asset('assets/js/admin.js') }}"></script>

<script src="{{ asset('assets/js/bootstrap-switch.min.js') }}"></script>
