<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">

@section('htmlheader')
    @include('layouts.header')
@show

<body class="skin-blue sidebar-mini">


<div class="wrapper">

    <div class="container-fluid">
        <div class="row row-offcanvas row-offcanvas-left">




            <!-- Main content -->
            <section class="content">

            <div class="text-center">
                @if(Session::has('message'))
                    <p class="alert">{{ Session::get('message') }}</p>
                @endif
            </div>

            <!-- Your Page Content Here -->
            @yield('main-content')

            </section><!-- /.content -->
        </div>
    </div>

    @include('layouts.footer')

</div><!-- ./wrapper -->



</body>
</html>
