<!DOCTYPE html>
<html>
<head>
    <title>{{ trans('app.title') }}</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    <!-- Latest compiled and minified CSS -->
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">

    <!-- DataTables CSS -->
    <link href="{{ asset('assets/css/vendor/dataTables.bootstrap.css') }}" rel="stylesheet">

    <!-- DataTables Responsive CSS
    <link href="css/vendor/dataTables.responsive.css" rel="stylesheet">
    -->
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/admin.css') }}">

    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/bootstrap-switch.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/vendor/font-awesome/css/font-awesome.min.css') }}">

    <script src="//code.jquery.com/jquery-2.2.4.min.js"></script>


</head>
