<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">

@section('htmlheader')
    @include('layouts.header')
@show

<body class="skin-blue sidebar-mini">

@section('navbar')
    @include('layouts.navbar')
@show

<div class="wrapper">

    <div class="container-fluid">
        <div class="row row-offcanvas row-offcanvas-left">



<!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">

        @section('sidebar')
            @include('layouts.sidebar')
        @show

        <div class="col-sm-9 col-md-10 main">
            <!-- Main content -->
            <section class="content">

            <div class="text-center">
                @if(Session::has('message'))
                    <p class="alert">{{ Session::get('message') }}</p>
                @endif
            </div>

            <!-- Your Page Content Here -->
            @yield('main-content')

            </section><!-- /.content -->
        </div>

        </div><!-- /.content-wrapper -->
        </div>
    </div>

    @include('layouts.footer')

</div><!-- ./wrapper -->



</body>
</html>
