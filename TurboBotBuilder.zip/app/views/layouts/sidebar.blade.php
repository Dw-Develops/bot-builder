<div class="col-sm-3 col-md-2 sidebar-offcanvas" id="sidebar" role="navigation">
    <ul class='nav nav-sidebar'>
        <li><a href='{{ url('bots') }}' target=_top>{{ trans('app.bot') }}</a></li>
    </ul>
    <a href="http://turboplr.com/mm/" target=_blank><img border=0  src=http://turboplr.com/p/ttm/images/MM_btn2.png width=80% height=80% ></a><br>
</div><!--/span-->