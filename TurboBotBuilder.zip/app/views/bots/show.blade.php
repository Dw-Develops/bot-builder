@extends('layouts.app')

@section('htmlheader_title')
    {{--Integrations--}}
@endsection
@section('main-content')

    <h2>{{ $data->name }} Bot Management</h2>

    <a href="{{ url('bots/' . $data->id) . '/messages' }}" class="btn btn-primary">{{ trans('app.edit_messages') }}</a>

    <a href="{{ url('bots/' . $data->id) . '/menu' }}" class="btn btn-primary">{{ trans('app.edit_menu') }}</a>

    <a href="{{ url('bots/' . $data->id) . '/info' }}" class="btn btn-primary">{{ trans('app.show_config') }}</a>

    <a href="{{ url('bots/' . $data->id) . '/edit' }}" class="btn btn-primary">{{ trans('app.edit_bot') }}</a>

@endsection

