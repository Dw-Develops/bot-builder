@extends('layouts.app')

@section('htmlheader_title')
    {{--Integrations--}}
@endsection
@section('main-content')


<h1>{{ trans('app.edit_bot') }}</h1>

<!-- if there are creation errors, they will show here -->
{{ HTML::ul($errors->all()) }}

{{ Form::model($data, array('route' => array('bots.update', $data->id), 'method' => 'PUT')) }}

<div class="form-group">
    {{ Form::label('name', trans('forms.name')) }}
    {{ Form::text('name', Input::old('name'), array('class' => 'form-control')) }}
</div>

<div class="form-group">
    {{ Form::label('verify_token', trans('forms.verify_token')) }}
    {{ Form::text('verify_token', Input::old('verify_token') ? Input::old('verify_token') : $data['token'], array('class' => 'form-control')) }}
</div>

<div class="form-group">
    {{ Form::label('page_access_token', trans('forms.page_access_token')) }}
    {{ Form::text('page_access_token', Input::old('page_access_token'), array('class' => 'form-control')) }}
</div>

<div class="form-group">
    {{ Form::label('webhook_url', trans('forms.webhook_url')) }}
    {{ Form::text('webhook_url', Input::old('webhook_url'), array('class' => 'form-control')) }}
</div>


{{ Form::submit(trans('forms.save'), array('class' => 'btn btn-primary')) }}

{{ Form::close() }}


@endsection
