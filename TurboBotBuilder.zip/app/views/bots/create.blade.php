@extends('layouts.app')

@section('htmlheader_title')
    {{--Integrations--}}
@endsection
@section('main-content')

<script src="//cdn.ckeditor.com/4.5.11/standard/ckeditor.js"></script>
<h1>{{ trans('app.create_bot') }}</h1>

<!-- if there are creation errors, they will show here -->
{{ HTML::ul($errors->all()) }}

{{ Form::open(array('url' => 'bots')) }}

<div class="form-group">
    {{ Form::label('name', trans('forms.name')) }}
    {{ Form::text('name', Input::old('name'), array('class' => 'form-control')) }}
</div>

<div class="form-group">
    {{ Form::label('verify_token', trans('forms.verify_token')) }}
    {{ Form::text('verify_token', Input::old('verify_token') ? Input::old('verify_token') : $data['token'], array('class' => 'form-control')) }}
</div>

<div class="form-group">
    {{ Form::label('page_access_token', trans('forms.page_access_token')) }}
    {{ Form::text('page_access_token', Input::old('page_access_token'), array('class' => 'form-control')) }}
</div>

{{--
<div class="form-group">
    {{ Form::label('webhook_url', trans('forms.webhook_url')) }}
    {{ Form::text('webhook_url', url('fbot') . '/' . $data['id'], array('class' => 'form-control')) }}
</div>
--}}


{{ Form::submit(trans('forms.create'), array('class' => 'btn btn-primary')) }}

{{ Form::close() }}

{{--<script>
    CKEDITOR.replace('content');
</script>--}}

@endsection
