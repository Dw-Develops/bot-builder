@extends('layouts.app')

@section('htmlheader_title')
    {{--Integrations--}}
@endsection
@section('main-content')


<h1>{{ trans('app.show_config') }}</h1>

<!-- if there are creation errors, they will show here -->
{{ HTML::ul($errors->all()) }}

{{ Form::model($data, array('url' => 'bots/' . $currentBot->id . '/info', 'method' => 'PUT')) }}

<div class="form-group">
    {{ Form::label('webhook_url', trans('forms.webhook_url')) }} {{ $data->webhook_url }}

</div>

<div class="form-group">
    {{ Form::label('greeting', trans('forms.greeting')) }}
    {{ Form::textarea('greeting', Input::old('greeting'), array('class' => 'form-control', 'rows' => 2)) }}
</div>

<div class="form-group">
    {{ Form::label('ununderstood', trans('forms.ununderstood')) }}

    {{ Form::textarea('ununderstood', Input::old('ununderstood'), array('class' => 'form-control')) }}
</div>

{{ Form::submit(trans('app.continue'), array('class' => 'btn btn-primary')) }}

{{ Form::close() }}

{{--<a href="{{ url('bots/' . $data->id . '/messages') }}" class="btn btn-primary">{{ trans('app.continue') }}</a>--}}

@endsection
