<?php

class BotController extends BaseController {

    public function __construct()
    {
        $param = Route::current()->parameters();
        if (isset($param['bots'])) {
            $id = $param['bots'];
        } elseif (isset($param['id'])) {
            $id = $param['id'];
        }
        if (isset($id)) {
            $data = Bot::find($id);
            View::share('currentBot', $data);
        }
//        parent::_construct();
    }

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
        // get all the nerds
        $data = Bot::all();
        // load the view and pass the nerds
        return View::make('bots.index')
            ->with('data', $data);
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
        if (count(Bot::all()))
            return Redirect::to('bots');

	    $data = array();
        $data['token'] = str_random(16);
        return View::make('bots.create')
            ->with('data', $data);
	}


	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
        // validate
        // read more on validation at http://laravel.com/docs/validation
        $rules = array(
            'name'       => 'required',
            'page_access_token'       => 'required',
            'verify_token'       => 'required'
//            'webhook_url'      => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);

        // process the login
        if ($validator->fails()) {
            return Redirect::to('bots/create')
                ->withErrors($validator);
        } else {
            // store
            $post = new Bot;
            $post->name       = Input::get('name');
            $post->verify_token     = Input::get('verify_token');
            $post->page_access_token     = Input::get('page_access_token');
            $post->save();
            $post->webhook_url  = url('fbot', [], true) . '/' . $post->id;
            $post->save();
            // redirect
            Session::flash('message', trans('messages.bot_created'));
            return Redirect::to('bots/' . $post->id . '/info');
        }
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
        $data = Bot::find($id);

        return View::make('bots.show')
            ->with('data', $data);
	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
        $data = Bot::find($id);

        // show the view and pass the nerd to it
        return View::make('bots.edit')
            ->with('data', $data);
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
    {
        // validate
        // read more on validation at http://laravel.com/docs/validation
        $rules = array(
//            'title'       => 'required',
//            'content'      => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);

        // process the login
        if ($validator->fails()) {
            return Redirect::to('bots/' . $id . '/edit')
                ->withErrors($validator)
                ->withInput(Input::except('password'));
        } else {
            // store
            $post = Bot::find($id);
            $post->name       = Input::get('name');
            $post->verify_token     = Input::get('verify_token');
            $post->page_access_token     = Input::get('page_access_token');
            $post->webhook_url     = Input::get('webhook_url');
            $post->save();

            // redirect
            Session::flash('message', trans('messages.bot_updated'));
            return Redirect::to('bots');
        }
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
        // delete
        $post = Bot::find($id);
        $post->delete();

        // redirect
        Session::flash('message', trans('messages.bot_deleted'));
        return Redirect::to('bots');
	}

    public function getInfo($id)
    {
        $ununderstood = array(
            "Can you rephrase it please?",
            "Mmm, I don't understand. What are you trying to do?",
            "Not following, what do you want to do?",
            "Reply with HELP if you want to learn how to use this bot.",
            "I do not comprehend. Can you use different wording?",
            "Not sure what you're talking about. Can you try again?"
        );

        $data = Bot::find($id);
        if (!$data->greeting)
            $data->greeting = "Hi {{user_first_name}}, welcome to this bot.";
        if (!$data->ununderstood)
            $data->ununderstood = implode(PHP_EOL, $ununderstood);
        else
            $data->ununderstood = implode(PHP_EOL, json_decode($data->ununderstood, true));
        // show the view and pass the nerd to it
        return View::make('bots.info')
            ->with('data', $data);
    }

    public function putInfo($id)
    {
        $item = Bot::find($id);
        $item->greeting = Input::get('greeting');
        $item->ununderstood = json_encode(explode(PHP_EOL, Input::get('ununderstood')));
        $item->save();
        Fbot::setGreeting($id);
        return Redirect::to("bots/{$id}/messages");
    }

}
