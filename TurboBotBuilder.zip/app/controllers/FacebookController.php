<?php

use pimax\FbBotApp;
use pimax\Messages\Message;
use pimax\Messages\ImageMessage;
use pimax\UserProfile;
use pimax\Messages\MessageButton;
use pimax\Messages\StructuredMessage;
use pimax\Messages\MessageElement;
use pimax\Messages\MessageReceiptElement;
use pimax\Messages\Address;
use pimax\Messages\Summary;
use pimax\Messages\Adjustment;


class FacebookController extends BaseController {


    public function __construct()
    {
        Config::set('session.driver', 'array');
    }

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index($id)
	{
        $bot = Fbot::getBot($id, $verify_token);

        if ( /*false &&  */!empty($_REQUEST['hub_mode']) && $_REQUEST['hub_mode'] == 'subscribe' && $_REQUEST['hub_verify_token'] == $verify_token) {

            // Webhook setup request
            echo $_REQUEST['hub_challenge'];
        } else {
            // Other event

            $data = json_decode(file_get_contents("php://input"), true, 512, JSON_BIGINT_AS_STRING);
//            $t = microtime();
//            file_put_contents('1-' . $t, print_r($data, true));
//            file_put_contents('2', file_get_contents("php://input"));
            if (!empty($data['entry'][0]['messaging'])) {
                foreach ($data['entry'][0]['messaging'] as $message) {

//                    file_put_contents('3', print_r($message, true));
                    // Skipping delivery messages and echo
//                    if (!empty($message['delivery']) || (isset($message['is_echo']) && $message['is_echo'] == 1)) {
                    if (!empty($message['delivery'])) {
                        continue;
                    }
//                    file_put_contents('3.5', print_r($data, true));
                    $command = "";

                    // When bot receive message from user
                    if (!empty($message['message'])) {
                        $command = $message['message']['text'];


                        // When bot receive button click from user
                    } else if (!empty($message['postback'])) {
                        $command = $message['postback']['payload'];
                    }

                    // Process only messages!!!!
                    if (!isset($message['message'])) {
                        continue;
                    }
//                    file_put_contents('41', print_r($command, true));
                    $custom_message = Fbot::getResponse($id, $command);
//                    file_put_contents('4', print_r($custom_message, true));
                    if ($custom_message) {
                        $command = 'custom_message';
                    }
//                    file_put_contents('412', print_r($command, true));


//                    if(preg_match('[time|current time|now]', $command)) {
//                        $command = 'time';
//                    }


                    // Handle command
                    switch ($command) {
                        case 'custom_message':
                            $bot->send(new Message($message['sender']['id'], $custom_message));
//                            $bot->send(new Message($message['sender']['id'], 'Sorry. I don’t understand you.'));
                            break;
                        // Other message received
                        default:
//                    file_put_contents('2', print_r($data['entry'][0]['messaging'], true));
                            $bot->send(new Message($message['sender']['id'], Fbot::getUnunderstood($id)));
//                            $bot->send(new Message($message['sender']['id'], 'Sorry. I don’t understand you.'));
                    }
                }
            }

        die();

	}
	}



}
