<?php

class MenuController extends BaseController {

    public function __construct()
    {

        $data = Bot::find(Route::current()->parameters()['bot_id']);
        View::share('currentBot', $data);
//        parent::_construct();
    }

    /**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index($bot_id)
	{
        // get all the nerds
        $data = Bot::find($bot_id)->menus;
        // load the view and pass the nerds
        return View::make('menu.index')
            ->with('data', $data);
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create($bot_id)
	{
        return View::make('menu.create');
	}


	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store($bot_id)
	{
        // validate
        // read more on validation at http://laravel.com/docs/validation
        $rules = array(
            'title'       => 'required',
            'url'       => 'required',
        );
        $validator = Validator::make(Input::all(), $rules);

        // process the login
        if ($validator->fails()) {
            return Redirect::to("bots/{$bot_id}/menu/create")
                ->withErrors($validator);
        } else {
            // store
            $item = new Menu;
            $item->title = Input::get('title');
            $item->url = Input::get('url');
            $item->bot_id = $bot_id;
            $item->save();
            Fbot::setMenu($bot_id);
            // redirect
            Session::flash('message', trans('messages.menu_created'));
            return Redirect::to("bots/{$bot_id}/menu");
        }
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($bot_id, $id)
	{
        $data = Bot::find($id);

        // show the view and pass the nerd to it
        return View::make('menu.show')
            ->with('data', $data);
	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($bot_id, $id)
	{
        $data = Menu::find($id);

        // show the view and pass the nerd to it
        return View::make('menu.edit')
            ->with('data', $data);
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $bot_id
	 * @param  int  $id
	 * @return Response
	 */
	public function update($bot_id, $id)
    {
        // validate
        // read more on validation at http://laravel.com/docs/validation
        $rules = array(
            'title'       => 'required',
            'url'      => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);

        // process the login
        if ($validator->fails()) {
            return Redirect::to();
            return Redirect::to("bots/{$bot_id}/menu/{$id}/edit");
        } else {
            // store
            $post = Menu::find($id);
            $post->title       = Input::get('title');
            $post->url     = Input::get('url');
            $post->save();
            Fbot::setMenu($bot_id);
            // redirect
            Session::flash('message', trans('messages.bot_updated'));
            return Redirect::to("bots/{$bot_id}/menu");
        }
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $bot_id
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($bot_id, $id)
	{
        // delete
        $post = Menu::find($id);
        $post->delete();

        // redirect
        Session::flash('message', trans('messages.menu_deleted'));
        return Redirect::to("bots/{$bot_id}/menu");
	}

    public function getInfo($id)
    {
        $data = Bot::find($id);

        // show the view and pass the nerd to it
        return View::make('menu.info')
            ->with('data', $data);
    }

}
