<?php

//use Auth;
use Illuminate\Http\Request;
//use Validator;

class AdminController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

//    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
    protected $redirectTo = 'bots';



    public function getForgot() {
        return View::make('admin.forgot');
    }

    public function postForgot() {
        if ( $user = User::where('email', '=', Input::get('email'))->first()) {

            $data = str_random(6);
            $user->password = Hash::make($data);
            $user->save();
            Mail::send('emails.forgot', array('data' => $data), function ($message) {
                $message->to(Input::get('email'), 'Admin')->subject('Password Reset');
            });
            return Redirect::to('admin/login')->with('message', trans('messages.pass_sent'));
        } else {
            return Redirect::to('admin/forgot')->with('message', trans('messages.wrong_email'))->withInput();
        }
    }


    public function getProfile() {
        return View::make('admin.profile');
    }

    public function postProfile() {
        $validator = Validator::make(Input::all(), User::$update_rules);

        if ($validator->passes()) {
            $user = User::firstOrFail();
            $user->email = Input::get('email');
            $user->password = Hash::make(Input::get('password'));
            $user->save();
            return Redirect::to('admin/profile')->with('message', trans('messages.profile_updated'));
        } else {
            return Redirect::to('admin/profile')->with('message', trans('messages.following_errors'))->withErrors($validator)->withInput();
        }
        return View::make('admin.profile');
    }

    public function getRegister() {
        if (User::count())
            return Redirect::to('admin/login');
        return View::make('admin.register');
    }

    public function postCreate() {
        $validator = Validator::make(Input::all(), User::$rules);

        if ($validator->passes()) {
            $user = new User;
            $user->email = Input::get('email');
            $user->password = Hash::make(Input::get('password'));
            $user->save();

            return Redirect::to('admin/login')->with('message', trans('messages.registration_tanks'));
        } else {
            return Redirect::to('admin/register')->with('message', trans('messages.following_errors'))->withErrors($validator)->withInput();
        }
    }

    public function getLogin() {
        return View::make('admin.login');
    }

    public function postLogin() {
        if (Auth::attempt(array('email'=>Input::get('email'), 'password'=>Input::get('password')), Input::get('remember'))) {
            return Redirect::to($this->redirectTo)->with('message', trans('messages.you_logged_in'));
        } else {
            return Redirect::to('admin/login')
                ->with('message', trans('messages.login_error'))
                ->withInput();
        }
    }

    public function index()
    {
        return view('login');
    }

    public function getLogout()
    {
        Auth::logout();
        return Redirect::to('admin/login')->with('message', trans('messages.logout'));
    }
}


