<?php

class MessageController extends BaseController {

    public function __construct()
    {

        $data = Bot::find(Route::current()->parameters()['bot_id']);
        View::share('currentBot', $data);
//        parent::_construct();
    }

    /**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index($bot_id)
	{
        $data = Bot::find($bot_id)->messages;
        // load the view and pass the nerds
        return View::make('messages.index')
            ->with('data', $data);
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create($bot_id)
	{
        return View::make('messages.create');
	}


	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store($bot_id)
	{
        // validate
        // read more on validation at http://laravel.com/docs/validation
        $rules = array(
            'user_says'       => 'required',
            'bot_says'       => 'required',
        );
        $validator = Validator::make(Input::all(), $rules);

        // process the login
        if ($validator->fails()) {
            return Redirect::to("bots/{$bot_id}/messages/create")
                ->withErrors($validator);
        } else {
            // store
            $item = new Message;
            $item->user_says = Input::get('user_says');
            $item->bot_says = Input::get('bot_says');
            $item->bot_id = $bot_id;
            $item->save();
            // redirect
            Session::flash('message', trans('messages.message_created'));
            return Redirect::to("bots/{$bot_id}/messages");
        }
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($bot_id, $id)
	{
        $data = Bot::find($id);

        // show the view and pass the nerd to it
        return View::make('messages.show')
            ->with('data', $data);
	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($bot_id, $id)
	{
        $data = Message::find($id);

        // show the view and pass the nerd to it
        return View::make('messages.edit')
            ->with('data', $data);
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $bot_id
	 * @param  int  $id
	 * @return Response
	 */
	public function update($bot_id, $id)
    {
        // validate
        // read more on validation at http://laravel.com/docs/validation
        $rules = array(
//            'title'       => 'required',
//            'content'      => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);


        if ($validator->fails()) {
            return Redirect::to("bots/{$bot_id}/messages/{$id}/edit")
                ->withErrors($validator);
        } else {
            // store
            $item = Message::find($id);
            $item->user_says = Input::get('user_says');
            $item->bot_says = Input::get('bot_says');
            $item->save();

            // redirect
            Session::flash('message', trans('messages.message_updated'));
            return Redirect::to("bots/{$bot_id}/messages");
        }
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $bot_id
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($bot_id, $id)
	{
        // delete
        $post = Message::find($id);
        $post->delete();

        // redirect
        Session::flash('message', trans('messages.message_deleted'));
        return Redirect::to("bots/{$bot_id}/messages");
	}


    public function getExport($bot_id)
    {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=messages.csv');
        $output = fopen('php://output', 'w');
        fputcsv($output, array(trans('forms.bot_says'), trans('forms.user_says')));
        $data = Bot::find($bot_id)->messages;
        foreach ($data as $v) {
            fputcsv($output, array($v->user_says, $v->bot_says));
        }
        exit;
    }


    public function getImport($bot_id)
    {
        return View::make('messages.import');
    }

    public function postImport($bot_id)
    {
        $csv = array_map('str_getcsv', file(Input::file('csv_file')->getRealPath()));
        unset($csv[0]);
        foreach ($csv as $v) {
            // store
            $item = new Message;
            $item->user_says = $v[0];
            $item->bot_says = $v[1];
            $item->bot_id = $bot_id;
            $item->save();
        }
        // redirect
        Session::flash('message', trans('messages.message_created'));
        return Redirect::to("bots/{$bot_id}/messages");
    }
}
