<?php

/*
 * Taken from
 * https://github.com/laravel/framework/blob/5.2/src/Illuminate/Auth/Console/stubs/make/controllers/HomeController.stub
 */


use Illuminate\Http\Request;

/**
 * Class InstallController
 * @package App\Http\Controllers
 */
class InstallController extends Controller
{

    /**
     * Show the application dashboard.
     *
     * @return Response
     */
    public function index()
    {
        return View::make('install');
    }
}