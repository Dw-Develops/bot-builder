<?php

use Illuminate\Database\Eloquent\Model as Eloquent;

class Message extends Eloquent
{

    protected $fillable = [
        'user_says',
        'bot_says',
        'reply_type',
        'bot_id'
    ];

//    public $timestamps = false;
    public function bot()
    {
        return $this->belongsTo('Bot');
    }
}