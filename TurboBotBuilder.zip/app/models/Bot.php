<?php

use Illuminate\Database\Eloquent\Model as Eloquent;

class Bot extends Eloquent {

    protected $fillable = [
        'name',
        'verify_token',
        'page_access_token',
        'webhook_url'
    ];

//    public $timestamps = false;

    public function messages()
    {
        return $this->hasMany('Message');
    }
    public function menus()
    {

        return $this->hasMany('Menu');
    }
}