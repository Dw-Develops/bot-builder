<?php

use Illuminate\Database\Eloquent\Model as Eloquent;

class Menu extends Eloquent
{

    protected $fillable = [
        'title',
        'url',
        'bot_id'
    ];

//    public $timestamps = false;
    public function bot()
    {
        return $this->belongsTo('Bot');

    }
}