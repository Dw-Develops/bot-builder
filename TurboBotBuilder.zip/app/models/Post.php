<?php

class Post extends Eloquent
{

}