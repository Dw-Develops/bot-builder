<?php

use pimax\FbBotApp;
use pimax\Messages\Message;
use pimax\Messages\ImageMessage;
use pimax\UserProfile;
use pimax\Messages\MessageButton;
use pimax\Messages\StructuredMessage;
use pimax\Messages\MessageElement;
use pimax\Messages\MessageReceiptElement;
use pimax\Messages\Address;
use pimax\Messages\Summary;
use pimax\Messages\Adjustment;

class Fbot
{
    public static function setMenu($botId)
    {
        $result = Bot::find($botId)->menus;
        if (!$result)
            return;
        $array = array();
        foreach ($result as $v) {
            $array[] = new MessageButton(MessageButton::TYPE_WEB, $v->title, $v->url);
        }
        $bot = static::getBot($botId, $verify_token);
        $bot->setPersistentMenu($array);
    }

    public static function setGreeting($botId)
    {
        $bot = static::getBot($botId, $verify_token);
        $bot->setGreeting(Bot::find($botId)->greeting);
    }

    public static function getResponse($botId, $message)
    {
        $message = strtolower($message);
// 1st option
//        $message = Message::whereRaw("lower(user_says) = '{$message}' and bot_id = {$botId}");
//        $result = $message->get()->first();

// 2nd option
        $message = SQLite3::escapeString($message);
        $result = Bot::find($botId)->messages()->whereRaw("lower(user_says) = '{$message}'")->first();
        if ($result)
            return $result->bot_says;
        return '';
    }

    public static function getUnunderstood($botId)
    {
        $array = json_decode(Bot::find($botId)->ununderstood, true);
        if (!$array)
            return 'Sorry. I don’t understand you.';
        return $array[mt_rand(0, count($array) - 1)];
    }

    public static function getBot($id, &$verify_token)
    {
        $data = Bot::find($id);

//dd(Fbot::getResponse(4, 'hi'));
//        $verify_token = "My_Verify_token"; // Verify token
        $verify_token = $data->verify_token;
//        $token = "EAAQNVtzImcMBABuEjxv2mNxSE9iiQHZC7kqYUiImmJqZBL1IqHr2S7MYVlKUyZCuCyFN524o8QebWjeAgNvlb1rz2jbN02ZAZA7KL84OkYKMhlzKehyZC6mgvSanBwU0sn99OhCoOr6YPYe7Qgkjl9a2DwgUqeSSZBaZBTqN7HizNAZDZD";
        $token = $data->page_access_token;


// Make Bot Instance
        return new FbBotApp($token);
    }


}