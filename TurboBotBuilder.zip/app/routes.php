<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/


Route::get('admin/login', 'AdminController@getLogin');
Route::post('admin/login', 'AdminController@postLogin');


Route::get('admin/register', 'AdminController@getRegister');
Route::post('admin/create', 'AdminController@postCreate');

Route::get('admin/forgot', 'AdminController@getForgot');
Route::post('admin/forgot', 'AdminController@postForgot');

Route::get('/', 'DefaultController@index');

Route::get('install', 'InstallController@index');

Route::group(array('before' => 'auth'), function () {
    Route::get('home', 'HomeController@index');
    Route::get('admin/logout','AdminController@getLogout');
    Route::resource('bots', 'BotController');

    Route::get('bots/{bot_id}/messages/export', 'MessageController@getExport');
    Route::get('bots/{bot_id}/messages/import', 'MessageController@getImport');
    Route::post('bots/{bot_id}/messages/import', 'MessageController@postImport');

    Route::resource('bots/{bot_id}/messages', 'MessageController');
    Route::resource('bots/{bot_id}/menu', 'MenuController');
    Route::get('bots/{id}/info', 'BotController@getInfo');
    Route::put('bots/{id}/info', 'BotController@putInfo');
    Route::get('admin/profile', 'AdminController@getProfile');
    Route::post('admin/profile', 'AdminController@postProfile');

});

Route::any('fbot/{id}', 'FacebookController@index');

