<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMessagesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
        Schema::create('messages', function ($table) {
            $table->increments('id');
            $table->string('user_says');
            $table->string('bot_says');
            $table->string('reply_type')->default('');
            $table->string('bot_id')->unsigned();
            $table->foreign('bot_id')->references('id')->on('bots');
            $table->timestamps();
        });
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
        Schema::drop('messages');
	}

}
