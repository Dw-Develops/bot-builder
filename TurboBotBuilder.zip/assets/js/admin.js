$(document).ready(function() {
	$('[data-toggle=offcanvas]').click(function() {
		$('.row-offcanvas').toggleClass('active');
	});

	$('.altauth-datatable').DataTable({
			order: [],
	        responsive: true,
	});

/*
 	tinymce.init({
 		selector: "#ls-page-content", 
 		menubar: "edit insert view format table tools", 
 		toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image table | preview media fullpage | fontselect fontsizeselect forecolor backcolor emoticons',
 		plugins: [
		  'advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker',
		  'searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking',
		  'save table contextmenu directionality emoticons template paste textcolor'
		],
		content_css: "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css",
 	});
*/

 	$('#uploadFile').change( function() {
 		$('#file').val($('#uploadFile').val().replace("C:\\fakepath\\", ""));

 		if($('#file').val() != ''){
 			$('#submit_file').show();	
 		} else {
 			$('#submit_file').hide();
 		}
 		
 	})

});

